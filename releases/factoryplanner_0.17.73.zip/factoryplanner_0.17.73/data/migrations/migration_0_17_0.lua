-- This file is a model for a single migration script and should not be applied

migration_0_17_0 = {}

function migration_0_17_0.global()
end

function migration_0_17_0.player_table(player, player_table)
end

function migration_0_17_0.subfactory(player, subfactory)
end