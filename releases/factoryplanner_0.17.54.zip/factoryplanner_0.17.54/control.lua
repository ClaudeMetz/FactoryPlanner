require("data.init")
require("ui.listeners")

if devmode then Profiler = require("lualib.profiler") end