local Object = require("backend.data.Object")
local Fuel = require("backend.data.Fuel")
local ModuleSet = require("backend.data.ModuleSet")

---@class Machine: Object, ObjectMethods
---@field class "Machine"
---@field parent Line
---@field proto FPMachinePrototype | FPPackedPrototype
---@field quality_proto FPQualityPrototype
---@field limit number?
---@field force_limit boolean
---@field fuel Fuel?
---@field module_set ModuleSet
---@field amount number
---@field total_effects ModuleEffects
---@field effects_tooltip LocalisedString
---@field recipe_effects ModuleEffects?
local Machine = Object.methods()
Machine.__index = Machine
script.register_metatable("Machine", Machine)

---@param proto FPMachinePrototype
---@param parent Line
---@return Machine
local function init(proto, parent)
    local object = Object.init({
        proto = proto,
        quality_proto = defaults.get_fallback("qualities").proto,
        limit = nil,
        force_limit = true,  -- ignored if limit is not set
        fuel = nil,  -- needs to be set by calling Machine.normalize_fuel afterwards
        module_set = nil,

        amount = 0,
        total_effects = nil,
        effects_tooltip = "",
        recipe_effects = nil,

        parent = parent
    }, "Machine", Machine)  --[[@as Machine]]
    object.module_set = ModuleSet.init(object)
    return object
end


function Machine:index()
    OBJECT_INDEX[self.id] = self
    if self.fuel then self.fuel:index() end
    self.module_set:index()
end


---@return {name: string, quality: string}
function Machine:elem_value()
    return {name=self.proto.name, quality=self.quality_proto.name}
end


---@param player LuaPlayer
function Machine:normalize_fuel(player)
    if self.proto.energy_type ~= "burner" then self.fuel = nil; return end
    -- no need to continue if this machine doesn't have a burner

    local burner = self.proto.burner
    -- Check if fuel has a valid category for this machine, replace otherwise
    if self.fuel and not burner.categories[self.fuel.proto.category] then self.fuel = nil end

    -- If this machine has fuel already, don't replace it
    if self.fuel == nil then
        local default_fuel_proto = defaults.get(player, "fuels", burner.combined_category).proto
        self.fuel = Fuel.init(default_fuel_proto, self)
    end
end


function Machine:summarize_effects()
    local module_effects = self.module_set:get_effects()
    local machine_effects = self.proto.effect_receiver.base_effect

    self.total_effects = util.effects.merge({module_effects, machine_effects, self.recipe_effects})
    self.effects_tooltip = util.effects.format(module_effects,
        {machine_effects=machine_effects, recipe_effects=self.recipe_effects})

    self.parent:summarize_effects()
end

---@return boolean uses_effects
function Machine:uses_effects()
    if self.proto.effect_receiver == nil then return false end
    return self.proto.effect_receiver.uses_module_effects
end

--- Called when the solver runs because it's the most convenient spot for it
---@param force LuaForce
---@param factory Factory
function Machine:update_recipe_effects(force, factory)
    local recipe_proto = self.parent.recipe_proto

    local recipe_name = nil
    if self.proto.quality_category == "mining-drill" then recipe_name = "custom-mining"
    elseif recipe_proto.productivity_recipe then recipe_name = recipe_proto.productivity_recipe
    elseif not recipe_proto.custom then recipe_name = recipe_proto.name
    else return end  -- no recipe effects for custom recipes

    local recipe_bonus = factory:get_productivity_bonus(force, recipe_name)
    if recipe_bonus >= 0 then
        self.recipe_effects = {productivity=recipe_bonus}
        self:summarize_effects()
    end
end


function Machine:compile_fuel_filter()
    local compatible_fuels = {}

    local fuel_category = prototyper.util.find("fuels", nil, self.proto.burner.combined_category)
    for _, fuel_proto in pairs(fuel_category.members) do
        table.insert(compatible_fuels, fuel_proto.name)
    end

    return {{filter="name", name=compatible_fuels}}
end

---@param player LuaPlayer
function Machine:reset(player)
    self.limit = nil
    self.force_limit = true

    local machine_default = defaults.get(player, "machines", self.proto.category)
    self.module_set:clear()
    if machine_default.modules then self.module_set:ingest_default(machine_default.modules) end

    if self.proto.burner ~= nil then
        local fuel_default = defaults.get(player, "fuels", self.proto.burner.combined_category)
        self.fuel = Fuel.init(fuel_default.proto, self)
    end
end


---@param object CopyableObject
---@return boolean success
---@return string? error
function Machine:paste(object, player)
    if object.class == "Machine" then
        local corresponding_proto = prototyper.util.find("machines", object.proto.name, self.proto.category)
        if corresponding_proto and self.parent:is_machine_applicable(object.proto) then
            self.parent:change_machine_to_proto(player, corresponding_proto)
            -- The above adjusts modules and fuel as well

            self.quality_proto = object.quality_proto
            self.limit = object.limit
            self.force_limit = object.force_limit

            return true, nil
        else
            return false, "incompatible"
        end
    elseif object.class == "Module" then
       return self.module_set:paste(object)
    else
        return false, "incompatible_class"
    end
end


---@class PackedMachine: PackedObject
---@field class "Machine"
---@field proto FPMachinePrototype
---@field quality_proto FPQualityPrototype
---@field limit number?
---@field force_limit boolean
---@field fuel PackedFuel?
---@field module_set PackedModuleSet

---@return PackedMachine packed_self
function Machine:pack()
    return {
        class = self.class,
        proto = prototyper.util.simplify_prototype(self.proto, "category"),
        quality_proto = prototyper.util.simplify_prototype(self.quality_proto, nil),
        limit = self.limit,
        force_limit = self.force_limit,
        fuel = self.fuel and self.fuel:pack(),
        module_set = self.module_set:pack()
    }
end

---@param packed_self PackedMachine
---@param parent Line
---@return Machine machine
local function unpack(packed_self, parent)
    local unpacked_self = init(packed_self.proto, parent)
    unpacked_self.quality_proto = packed_self.quality_proto
    unpacked_self.limit = packed_self.limit
    unpacked_self.force_limit = packed_self.force_limit
    unpacked_self.fuel = packed_self.fuel and Fuel.unpack(packed_self.fuel, unpacked_self)
    unpacked_self.module_set = ModuleSet.unpack(packed_self.module_set, unpacked_self)

    return unpacked_self
end

---@return Machine clone
function Machine:clone()
    local clone = unpack(self:pack(), self.parent)

    -- Copy these over so we don't need to run the solver
    clone.amount = self.amount
    clone.recipe_effects = self.recipe_effects
    if self.fuel then
        clone.fuel.amount = self.fuel.amount
        clone.fuel.satisfied_amount = self.fuel.satisfied_amount
    end

    clone:validate()
    return clone
end


---@return boolean valid
function Machine:validate()
    self.proto = prototyper.util.validate_prototype_object(self.proto, "category")
    self.valid = (not self.proto.simplified)

    self.quality_proto = prototyper.util.validate_prototype_object(self.quality_proto, nil)
    self.valid = (not self.quality_proto.simplified) and self.valid

    if self.valid and self.parent.valid then
        self.valid = self.parent:is_machine_applicable(self.proto)
    end

    -- If the machine changed to not use a burner, remove its fuel
    if not self.proto.burner then self.fuel = nil end
    if self.fuel and self.valid then self.valid = self.fuel:validate() end

    self.valid = self.module_set:validate() and self.valid

    return self.valid
end

---@param player LuaPlayer
---@return boolean success
function Machine:repair(player)
    -- If the prototype is still simplified, it couldn't be fixed by validate
    -- A final possible fix is to replace this machine with the default for its category
    if self.proto.simplified and not self.parent:change_machine_to_default(player) then
        return false  -- if this happens, the whole line can not be salvaged
    end
    self.valid = true  -- if it gets to this, change_machine was successful and the machine is valid
    -- It just might need to cleanup some fuel, modules and/or quality

    if self.quality_proto.simplified then
        self.quality_proto = defaults.get_fallback("qualities").proto
    end

    if self.fuel and not self.fuel.valid and not self.fuel:repair(player) then
        -- If fuel is unrepairable, replace it with a default value
        self.fuel = nil; self:normalize_fuel(player)
    end

    self.module_set:repair(player)

    return self.valid
end

return {init = init, unpack = unpack}
