local migration = {}

function migration.global()
    global.nth_tick_events = {}
end

function migration.player_table(player_table)
end

function migration.subfactory(subfactory)
end

function migration.packed_subfactory(packed_subfactory)
end

return migration
