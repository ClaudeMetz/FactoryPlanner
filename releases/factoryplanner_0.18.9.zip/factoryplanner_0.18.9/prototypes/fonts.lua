data:extend({
    {
        type = "font",
        name = "fp-font-14p",
        from = "default",
        size = 14
    },
    {
        type = "font",
        name = "fp-font-14p-semi",
        from = "default-semibold",
        size = 14
    },
    {
        type = "font",
        name = "fp-font-15p",
        from = "default-semibold",
        size = 15
    },
    {
        type = "font",
        name = "fp-font-mono-15p",
        from = "default-mono",
        size = 15
    },
    {
        type = "font",
        name = "fp-font-mono-16p",
        from = "default-mono",
        size = 16
    },
    {
        type = "font",
        name = "fp-font-bold-15p",
        from = "default-bold",
        size = 15
    },
    {
        type = "font",
        name = "fp-font-16p",
        from = "default",
        size = 16
    },
    {
        type = "font",
        name = "fp-font-semibold-16p",
        from = "default-semibold",
        size = 16
    },
    {
        type = "font",
        name = "fp-font-bold-16p",
        from = "default-bold",
        size = 16
    },
    {
        type = "font",
        name = "fp-font-18p",
        from = "default",
        size = 18
    },
    {
        type = "font",
        name = "fp-font-semibold-18p",
        from = "default-semibold",
        size = 18
    },
    {
        type = "font",
        name = "fp-font-20p",
        from = "default",
        size = 20
    },
    {
        type = "font",
        name = "fp-font-bold-20p",
        from = "default-bold",
        size = 20
    },
    {
        type = "font",
        name = "fp-font-bold-26p",
        from = "default-bold",
        size = 26
    }
})