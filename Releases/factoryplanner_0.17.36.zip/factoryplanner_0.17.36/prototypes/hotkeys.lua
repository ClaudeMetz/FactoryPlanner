data:extend({
    {
        type = "custom-input",
        name = "fp_toggle_main_dialog",
        key_sequence = "CONTROL + R",
        consuming = "all",
        order = "a"
    },
    {
        type = "custom-input",
        name = "fp_cycle_production_views",
        key_sequence = "TAB",
        consuming = "script-only",
        order = "b"
    }
})