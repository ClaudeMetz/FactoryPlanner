data:extend({
    {
        type = "custom-input",
        name = "fp_toggle_main_dialog",
        key_sequence = "CONTROL + R",
        consuming = "all"
    }
})