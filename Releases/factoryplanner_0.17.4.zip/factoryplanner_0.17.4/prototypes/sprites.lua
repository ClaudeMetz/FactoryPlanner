data:extend({
    {
        type = "sprite",
        name = "fp_sprite_plus",
        filename = "__factoryplanner__/graphics/plus.png",
        priority = "extra-high-no-scale",
        width = 32,
        height = 32
    }
})