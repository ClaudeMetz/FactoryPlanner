require("prototypes.hotkeys")
require("prototypes.fonts")
require("prototypes.styles")