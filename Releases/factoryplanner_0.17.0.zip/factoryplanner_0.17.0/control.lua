require("data.init")
require("ui.dialogs.main_dialog")