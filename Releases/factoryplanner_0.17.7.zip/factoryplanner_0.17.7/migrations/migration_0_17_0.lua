-- This file is a model for a single migration script and should not be applied

migration_0_17_0 = {}

function migration_0_17_0.Factory(factory)
end

function migration_0_17_0.Subfactory(subfactory)
end